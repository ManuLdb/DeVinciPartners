<div class="clear"></div>
</div>
<footer id="footer" role="contentinfo">
</footer>
</div>
<?php wp_footer(); ?>
</div>
</body>
</html>