<?php
// Template Name: Alumni
?>

<?php get_header(); ?>
<main id="alumni">

</main>
<?php get_footer(); ?>
