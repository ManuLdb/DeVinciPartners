<?php
// Template Name: Association
?>

<?php get_header(); ?>
<main id="association">

</main>
<?php get_footer(); ?>
