<?php
// Template Name: Accueil
?>

<?php get_header(); ?>
<main id="accueil">
    <div class="row">
        <div class="col s12">
            <p>
                Lorem ipsum dolor sit amet,
                consectetur adipisicing elit.
                Ab accusantium asperiores dicta dignissimos dolorum enim exercitationem incidunt iste iure nam, neque nostrum,
                officiis porro rerum sint temporibus ullam veniam voluptate!
                Lorem ipsum dolor sit amet,
                consectetur adipisicing elit.
                Ab accusantium asperiores dicta dignissimos dolorum enim exercitationem incidunt iste iure nam, neque nostrum,
                officiis porro rerum sint temporibus ullam veniam voluptate!            Lorem ipsum dolor sit amet,
                consectetur adipisicing elit.
                Ab accusantium asperiores dicta dignissimos dolorum enim exercitationem incidunt iste iure nam, neque nostrum,
                officiis porro rerum sint temporibus ullam veniam voluptate!            Lorem ipsum dolor sit amet,
                consectetur adipisicing elit.
                Ab accusantium asperiores dicta dignissimos dolorum enim exercitationem incidunt iste iure nam, neque nostrum,
                officiis porro rerum sint temporibus ullam veniam voluptate!            Lorem ipsum dolor sit amet,
                consectetur adipisicing elit.
                Ab accusantium asperiores dicta dignissimos dolorum enim exercitationem incidunt iste iure nam, neque nostrum,
                officiis porro rerum sint temporibus ullam veniam voluptate!            Lorem ipsum dolor sit amet,
                consectetur adipisicing elit.
                Ab accusantium asperiores dicta dignissimos dolorum enim exercitationem incidunt iste iure nam, neque nostrum,
                officiis porro rerum sint temporibus ullam veniam voluptate!            Lorem ipsum dolor sit amet,
                consectetur adipisicing elit.
                Ab accusantium asperiores dicta dignissimos dolorum enim exercitationem incidunt iste iure nam, neque nostrum,
                officiis porro rerum sint temporibus ullam veniam voluptate!
            </p>
        </div>
        <h2>Quelques entreprises partenaires</h2>
        <div id="scroller">
            <div class="zone">
                <ul>

                    <li style="left: 0px;"><img src="<?php echo get_stylesheet_directory_uri(); ?>/img/cerclerouge.png"  class="img-responsive" alt="cercle"></li>
                    <li style="left: 120px;"><img src="<?php echo get_stylesheet_directory_uri(); ?>/img/cerclerouge.png"  class="img-responsive" alt="cercle"></li>
                    <li style="left: 236px;"><img src="<?php echo get_stylesheet_directory_uri(); ?>/img/cerclerouge.png"  class="img-responsive" alt="cercle"></li>
                    <li style="left: 351px;"><img src="<?php echo get_stylesheet_directory_uri(); ?>/img/cerclerouge.png"  class="img-responsive" alt="cercle"></li>
                    <li style="left: 466px;"><img src="<?php echo get_stylesheet_directory_uri(); ?>/img/cerclerouge.png"  class="img-responsive" alt="cercle"></li>
                    <li style="left: 581px;"><img src="<?php echo get_stylesheet_directory_uri(); ?>/img/cerclerouge.png"  class="img-responsive" alt="cercle"></li>
                    <!--
                    <li style="left: 1353px;"><a href=""><img  src="img/a.png"></a></li>
                    <li style="left: 1438px;"><a href=""><img  src="img/a.png"></a></a></li>
                    <li style="left: 1538px;"><a href=""><img  src="img/a.png"></a></li>
                    <li style="left: 1668px;"><a href=""><img src="img/a.png"></a></li>
                    <li style="left: 1906px;"><a href=""><img  src="img/a.png"></a></li>
                    <li style="left: 2140px;"><a href=""><img  src="img/a.png" ></a></li>
                    <li style="left: 2304px;"><a href=""><img   src="img/a.png"></a></li>
                    <li style="left: 2535px;"><a href=""><img  src="img/a.png" ></a></li>
                    <li style="left: 2745px;"><a href=""><img  src="img/a.png" ></a></li>
                    <li style="left: 3011px;"><a href=""><img  src="img/a.png" ></a></li>
                    -->
                </ul>
            </div>
        </div>
    </div>
</main>
<?php get_footer(); ?>
